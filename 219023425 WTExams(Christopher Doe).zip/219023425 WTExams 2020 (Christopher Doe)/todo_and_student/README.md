# Todo

Angular, NodeJS, ExpressJS and MongoDB RESTful API Tutorial.
See [Creating a RESTful API Tutorial](http://adrianmejia.com/blog/2014/10/01/creating-a-restful-api-tutorial-with-nodejs-and-mongodb/) post for more details.

# Installation

You just need to install dependencies:

```bash
npm install
```

And start the program

```bash
npm start
```
